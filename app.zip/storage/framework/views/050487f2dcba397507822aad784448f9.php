<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <title>Insurance </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="<?php echo e(asset('frontend')); ?>/img/favicon.ico" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Poppins:wght@600;700&display=swap"
        rel="stylesheet" />

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('frontend')); ?>/lib/animate/animate.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend')); ?>/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('frontend')); ?>/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('frontend')); ?>/css/style.css" rel="stylesheet" />
    <!-- Activation JS -->
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/lib/wow/wow.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/lib/easing/easing.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/lib/counterup/counterup.min.js"></script>
    <!-- loader-->
    <link href="<?php echo e(asset('backend/assets/css/pace.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('backend/assets/js/pace.min.js')); ?>"></script>
    <script src="/backend/assets/js/sweet_alert.js" defer></script>
    

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('frontend')); ?>/js/main.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/frontend/app.js'); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>

<body>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
</body>

</html>
<?php /**PATH /home/modernit/insurance.softdevehsan.com/resources/views/app.blade.php ENDPATH**/ ?>
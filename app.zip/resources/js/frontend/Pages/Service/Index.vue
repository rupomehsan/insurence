<template>
    <!-- Page Header Start -->
    <div
        class="container-fluid page-header py-5 mb-5 wow fadeIn"
        data-wow-delay="0.1s"
    >
        <div class="container py-5">
            <h1 class="display-4 animated slideInDown mb-4">Services</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Services
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto" style="max-width: 500px">
                <h1 class="display-6 mb-5">
                    We Provide professional Insurance Services
                </h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.3s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-01-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">
                                Overseas Mediclaim Insurance (Health)
                            </h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <Link
                            class="btn btn-light px-3"
                            href="service/overseas-mediclaim-insurance"
                            >Buy now</Link
                        >
                    </div>
                </div>
                <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.1s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-08-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">Motor Insurance</h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <Link
                            class="btn btn-light px-3"
                            href="service/motor-insurance"
                            >Buy now</Link
                        >
                    </div>
                </div>

                <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.1s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-10-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">Life Insurance</h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <a class="btn btn-light px-3" href="">Buy now</a>
                    </div>
                </div>

                <!-- <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.5s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-05-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">Home Insurance</h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <a class="btn btn-light px-3" href="">Buy now</a>
                    </div>
                </div>

                <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.3s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-07-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">Business Insurance</h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <a class="btn btn-light px-3" href="">Buy now</a>
                    </div>
                </div>
                <div
                    class="col-lg-4 col-md-6 wow fadeInUp"
                    data-wow-delay="0.5s"
                >
                    <div class="service-item rounded h-100 p-5">
                        <div class="d-flex align-items-center ms-n5 mb-4">
                            <div
                                class="service-icon flex-shrink-0 bg-primary rounded-end me-4"
                            >
                                <img
                                    class="img-fluid"
                                    src="/frontend/img/icon/icon-06-light.png"
                                    alt=""
                                />
                            </div>
                            <h4 class="mb-0">Property Insurance</h4>
                        </div>
                        <p class="mb-4">
                            Aliqu diam amet eos erat ipsum et lorem et sit, sed
                            stet lorem sit clita duo justo erat amet
                        </p>
                        <a class="btn btn-light px-3" href="">Buy now</a>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
    <!-- Service End -->
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
